$(document).ready(function() {

	$('#login').click(function() {
		$('.auth-block').toggleClass('auth-active');
	});

});