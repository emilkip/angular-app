less.errorReporting = 'console';

describe("less.js error reporting console test", function() {
    testLessErrorsInDocument(true);
});